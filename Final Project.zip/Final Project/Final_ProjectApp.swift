//
//  Final_ProjectApp.swift
//  Final Project
//
//  Created by Aditi Sinha26 on 5/22/23.
//

import SwiftUI

@main
struct Final_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
